package exception3;

import java.io.FileOutputStream;

public class TryWithResources {
	public static void main(String[] args)
	{
		try(FileOutputStream f=new FileOutputStream("D://Xyz/Abc.txt");)
		{
			String s="This is try with resource";
			byte b[]=s.getBytes();
			f.write(b);
			f.close();
		}
		catch(Exception e) {
			System.out.println(e);
		}
		System.out.println("Data added successfully");
	}
}
