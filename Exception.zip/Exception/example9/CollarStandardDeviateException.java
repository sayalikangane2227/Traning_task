package example9;

public class CollarStandardDeviateException extends RuntimeException {

	public CollarStandardDeviateException(String s) {
		super(s);
	}

}
