package exception2;

public class AbscondingException extends Exception {
	public AbscondingException(String s) {
		// TODO Auto-generated constructor stub
		super(s);
	}
}
