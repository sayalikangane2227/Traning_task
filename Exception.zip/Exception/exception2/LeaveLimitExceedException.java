package exception2;

public class LeaveLimitExceedException extends Exception {
	public LeaveLimitExceedException(String s) {
		super(s);
	}

}
