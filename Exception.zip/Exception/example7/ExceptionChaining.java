package example7;

public class ExceptionChaining {
	public static void main(String[] args) {
	
			try {
				ArrayIndexOutOfBoundsException array=new ArrayIndexOutOfBoundsException("Exception");
				array.initCause(new ArrayIndexOutOfBoundsException("This is the cause of exception"));
				throw array;
				}
				catch(ArrayIndexOutOfBoundsException array) {
					System.out.println(array);
					System.out.println(array.getCause());
				}
			}
		
	}


