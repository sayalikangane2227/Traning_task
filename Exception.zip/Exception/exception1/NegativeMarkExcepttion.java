package exception1;

public class NegativeMarkExcepttion extends Exception {
	public NegativeMarkExcepttion(String msg) {
		super(msg);
		
	
	}

}
