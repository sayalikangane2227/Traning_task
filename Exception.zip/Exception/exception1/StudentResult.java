package exception1;

public class StudentResult {

	String maths;
	String science;
	String history;
	String Biology;
	public String getMaths() {
		return maths;
	}
	public void setMaths(String maths) {
		this.maths = maths;
	}
	public String getScience() {
		return science;
	}
	public void setScience(String science) {
		this.science = science;
	}
	public String getHistory() {
		return history;
	}
	public void setHistory(String history) {
		this.history = history;
	}
	public String getBiology() {
		return Biology;
	}
	public void setBiology(String biology) {
		Biology = biology;
	}
	
	
}
