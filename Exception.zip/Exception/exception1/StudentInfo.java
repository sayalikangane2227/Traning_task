package exception1;

import java.util.Scanner;

public class StudentInfo {
	Student s;
	StudentResult sr;
 
	
public void getData() {
	s=new Student();
	sr=new StudentResult();
	
 
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter rollno:");
       
        System.out.println("Enter sname:");
	
		System.out.println("Enter saddress");
		String s1=sc.next();
		System.out.println("Enter maths marks:");
		int m=sc.nextInt();
		System.out.println("Enter science marks:");
		int sw=sc.nextInt();
		System.out.println("Enter history marks:");
		int h=sc.nextInt();
		System.out.println("Enter bioology marks:");
		int b=sc.nextInt();
		}

	
	
	  
	
	


	

}
