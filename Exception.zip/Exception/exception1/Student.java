package exception1;

public class Student {
	int rollno;
    String snmae;
    String saddress;
    StudentResult srobj;
	public int getRollno() {
		return rollno;
	}
	public void setRollno(int rollno) {
		this.rollno = rollno;
	}
	public String getSnmae() {
		return snmae;
	}
	public void setSnmae(String snmae) {
		this.snmae = snmae;
	}
	public String getSaddress() {
		return saddress;
	}
	public void setSaddress(String saddress) {
		this.saddress = saddress;
	}
	public StudentResult getSrobj() {
		return srobj;
	}
	public void setSrobj(StudentResult srobj) {
		this.srobj = srobj;
	}
    
	
	

}
