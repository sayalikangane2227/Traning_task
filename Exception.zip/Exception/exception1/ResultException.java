package exception1;

public class ResultException extends Exception {
	public ResultException(String msg) {
		super(msg);

	}
	

}
