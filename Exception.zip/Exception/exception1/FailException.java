package exception1;

public class FailException extends Exception{
	public FailException(String msg) {
	super(msg);
	}

}
