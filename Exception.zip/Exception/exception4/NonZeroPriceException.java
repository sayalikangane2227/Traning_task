package exception4;

public class NonZeroPriceException extends Exception {
	NonZeroPriceException(String msg) {
		super(msg);
	}
}
