package exception4;

public class ItemPurchaseLimitExceed extends Exception {
	ItemPurchaseLimitExceed(String msg) {
		super(msg);
	}
}
