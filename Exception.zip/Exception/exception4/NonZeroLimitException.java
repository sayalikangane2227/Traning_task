package exception4;

public class NonZeroLimitException {

}
