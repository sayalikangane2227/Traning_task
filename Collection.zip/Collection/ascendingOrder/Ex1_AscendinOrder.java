package ascendingOrder;

import java.util.Set;
import java.util.TreeSet;

public class Ex1_AscendinOrder {
	public static void main(String[] args) {
		Set s=new TreeSet<>();
		s.add(12);
		s.add(1);
		s.add(56);
		s.add(25);
		s.add(7);
		System.out.println("Elements in ascending order:"
				+s);
		
	}

}
