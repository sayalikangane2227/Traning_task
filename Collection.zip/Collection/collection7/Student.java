package collection7;

public class Student {
	
	 int rollno;
	 String sname; 
	 String classname;
	 double avg1;
	 TotalMarks tm;
	public Student(int rollno, String sname, String classname, double avg1, TotalMarks tm) {
		super();
		this.rollno = rollno;
		this.sname = sname;
		this.classname = classname;
		this.avg1 = avg1;
		this.tm = tm;
	}
	@Override
	public String toString() {
		return "Student [rollno=" + rollno + ", sname=" + sname + ", classname=" + classname + ", avg1=" + avg1
				+ ", tm=" + tm + "]";
	}
	 
	 
	 
	 

	
	 

	
	 


}
