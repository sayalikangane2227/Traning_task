package collection7;

import java.util.ArrayList;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;


public class Task {
	
	Student st;
	TotalMarks tr;
	
	//Student stt[]= new Student[5];
	
	Scanner sc=new Scanner(System.in);
	List<Student> list = new ArrayList<Student>();
	double avg;
	
	public void m1()
	{
		
		System.out.println("How many Entry you want to add");
		int a1=sc.nextInt();
		
		for(int i=0;i<a1;i++)
		{
			System.out.println("add 4 Subject marks");
		tr=new TotalMarks(sc.nextDouble(), sc.nextDouble(),sc.nextDouble(),sc.nextDouble());
		
		avg=(tr.Geography+tr.Histroy+tr.Math+tr.Science)/4;
				
		
		System.out.println("roll name class");
		st=new Student(sc.nextInt(),sc.next(),sc.next(), avg, tr);
		
		
		list.add(st);
		}
		
		//list.forEach(System.out::println);	
		
			
	}
	
	
	public void display_below50()
	{
		
		for(Student st : list) {
			
			if(st.avg1<50 && st.avg1>30)
			{
			
				
			System.out.println("Student Name        "+st.sname);
			System.out.println("Studnet roll no     "+st.rollno);
			System.out.println("Student Class Name  "+st.classname);
			System.out.println("Geography Marks     "+st.tm.Geography);
			System.out.println("History Marks       "+st.tm.Histroy);
			System.out.println("Math Marks          "+st.tm.Math);
			System.out.println("Science Marks       "+st.tm.Science);
			System.out.println("Total Avrage        "+st.avg1);
			
			}
		}	
	}
	
	public void display_below30()
	{
		
		for(Student st : list) {
			
			if(st.avg1<30)
			{
			
				System.out.println("this Students fail in Exam Fail in exam \n");
				System.out.println("Student Name        "+st.sname);
				System.out.println("Studnet roll no     "+st.rollno);
				System.out.println("Student Class Name  "+st.classname);
				System.out.println("Geography Marks     "+st.tm.Geography);
				System.out.println("History Marks       "+st.tm.Histroy);
				System.out.println("Math Marks          "+st.tm.Math);
				System.out.println("Science Marks       "+st.tm.Science);
				System.out.println("Total Avrage        "+st.avg1);
				
			
			}
		}	
	}
	public void display_above50()
	{
		
		for(Student st : list) {
			
			if(st.avg1>=50)
			{
			
				System.out.println("Student Name        "+st.sname);
				System.out.println("Studnet roll no     "+st.rollno);
				System.out.println("Student Class Name  "+st.classname);
				System.out.println("Geography Marks     "+st.tm.Geography);
				System.out.println("History Marks       "+st.tm.Histroy);
				System.out.println("Math Marks          "+st.tm.Math);
				System.out.println("Science Marks       "+st.tm.Science);
				System.out.println("Total Avrage        "+st.avg1);
				
			
			}
		}	
	}
	
	String name;
	public void SearchByName()
	{
		System.out.println("Enter Name to Find");
		name=sc.next();
		
		for(Student st:list)
		{
			
			if(st.sname.contentEquals(name))
			{
				System.out.println("Student Name        "+st.sname);
				System.out.println("Studnet roll no     "+st.rollno);
				System.out.println("Student Class Name  "+st.classname);
				System.out.println("Geography Marks     "+st.tm.Geography);
				System.out.println("History Marks       "+st.tm.Histroy);
				System.out.println("Math Marks          "+st.tm.Math);
				System.out.println("Science Marks       "+st.tm.Science);
				System.out.println("Total Avrage        "+st.avg1);
			}
			
		}
		
	}
	
	public static void main(String[] args) {
		Task t =new Task();
		t.m1();
		Scanner sc= new Scanner(System.in);
		int n;
		
		do {
			System.out.println("");
			System.out.println(" 1. below 50 \n"
							+  " 2. below 30 \n"
							+  " 3. above 50 \n"
							+  " 4. search by Name \n");
		
			 n=sc.nextInt();
			
			switch (n) {
			case 1:
				t.display_below50();	
				break;
				
			case 2: 
				t.display_below30();
				break;
				
			case 3:
				
				t.display_above50();
				break;
				
			case 4: 
				
				t.SearchByName();
				break;

			default:
				System.out.println("invalid");
				break;
			}
			
		}
		while(n<=4);
		
	     
	}
	
	

}
