package collection7;

public class TotalMarks {
	
	double Math;
	double Science;
	double Geography;
	double Histroy;
	

	
	
	public TotalMarks(double math, double science, double geography, double histroy) {
		super();
		Math = math;
		Science = science;
		Geography = geography;
		Histroy = histroy;
	}
	@Override
	public String toString() {
		return "TotalMarks [Math=" + Math + ", Science=" + Science + ", Geography=" + Geography + ", Histroy=" + Histroy
				+ "]";
	}
	
	
	

}
