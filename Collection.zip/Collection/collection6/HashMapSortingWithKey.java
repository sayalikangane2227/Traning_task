package collection6;

import java.util.Map;
import java.util.HashMap;
import java.util.TreeMap;

public class HashMapSortingWithKey {

			static Map<String, Integer> map = new HashMap<>();

			public static void sortbykey()
			{
			TreeMap<String, Integer> sorted
					= new TreeMap<>(map);

				for (Map.Entry<String, Integer> entry :
					sorted.entrySet())
					System.out.println("Key = " + entry.getKey()
									+ ", Value = "
									+ entry.getValue());
			}

			public static void main(String args[])
			{
				map.put("Sayali", 12);
				map.put("Jaie", 14);
				map.put("Monali", 13);
				map.put("Neha", 12);
				map.put("Payal", 22);

				sortbykey();
			}
		}

